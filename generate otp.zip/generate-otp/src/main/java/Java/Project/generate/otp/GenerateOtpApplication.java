package Java.Project.generate.otp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenerateOtpApplication {

	public static void main(String[] args) {
		SpringApplication.run(GenerateOtpApplication.class, args);
	}

}
